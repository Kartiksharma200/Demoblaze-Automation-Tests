package com.stepDefinition;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pageObject.loginPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStep {

	WebDriver driver;
	loginPage login;

	@Given("User is on Home Page")
	public void user_is_on_home_page() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		driver.get("https://www.demoblaze.com/");
	}

	@When("User click on the Login button")
	public void user_click_on_the_login_button() {
		login.clickHomePageLoginBtn();
	}

	@When("enter the valid {string} and {string}")
	public void enter_the_valid_and(String username, String password) throws InterruptedException {
		login = new loginPage(driver);
		login.enterUsername(username);
		login.enterPassword(password);
	}

	@Then("click on the Login button")
	public void click_on_the_login_button() {
		login.clickLoginBtn();
	}

	@And("close the browser")
	public void close_the_browser() {
		driver.close();
	}
}
