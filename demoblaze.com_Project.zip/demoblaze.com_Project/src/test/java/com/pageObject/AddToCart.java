package com.pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AddToCart {
	WebDriver driver;
	
	
	By btn_cart = By.xpath("//a[@id='cartur']");
	
	By phones_categories = By.xpath("//div[@id='contcont']//a[2]");
	By phone = By.xpath("//a[normalize-space()='Iphone 6 32gb']");
	By phone_tittle = By.xpath("//h2[@class='name']");
	By addtocart_phone_btn = By.xpath("//a[@class='btn btn-success btn-lg']");
	By laptops_categories = By.xpath("//a[3]");
	By Laptop = By.xpath("//a[normalize-space()='MacBook air']");
	By laptop_tittle = By.xpath("//h2[@class='name']");
	By monitors_categories = By.xpath("//a[4]");
	By monitor = By.xpath("//a[normalize-space()='Apple monitor 24']");
	
	
	public AddToCart(WebDriver driver) {
		this.driver = driver;
	}
	
	public void addToPhone() throws InterruptedException {
		driver.findElement(phones_categories).click();
		Thread.sleep(3000);
		driver.findElement(phone).click();
		driver.findElement(phone_tittle).isDisplayed();
		Thread.sleep(3000);
		driver.findElement(addtocart_phone_btn).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}
	
	public void clickOnlaptop() throws InterruptedException {
		driver.findElement(By.xpath("//a[@id='nava']")).click();
		driver.findElement(laptops_categories).click();
		Thread.sleep(3000);
	}
	public void addToLaptop() throws InterruptedException {		
		driver.findElement(Laptop).click();
		Thread.sleep(3000);
		driver.findElement(laptop_tittle).isDisplayed();
		driver.findElement(By.xpath("//a[@class='btn btn-success btn-lg']")).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();	
	}
	public void clickOnMonitor() {
		driver.findElement(By.xpath("//a[@id='nava']")).click();
		driver.findElement(monitors_categories).click();
		
	}
	public void addToMonitor() {
		driver.findElement(monitor).click();
		driver.findElement(By.xpath("//h2[@class='name']")).isDisplayed();
		driver.findElement(By.xpath("//a[@class='btn btn-success btn-lg']")).click();
		driver.switchTo().alert().accept();
	}
	
	public void verifyCart() throws InterruptedException {
		driver.findElement(By.xpath("//a[@id='nava']")).click();
		Thread.sleep(3000);
		driver.findElement(btn_cart).click();
		
	}
	public void closebrowser() {
		driver.quit();
	}

}
